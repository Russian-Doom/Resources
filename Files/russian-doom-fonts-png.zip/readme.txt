Russian Doom PNG fonts
----------------------------

PNG font atlases from Russian Doom project
https://github.com/Russian-Doom

Feel free to use them for any noncommercial purposes.


-Julian Nechaevsky
